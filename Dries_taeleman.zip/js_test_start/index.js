const setup = () => {
    let kip = document.getElementById("kip").value;
    let letter = document.getElementById("letter").value.trim();
}
if(kip.value="kip met een ei"){
    const telSequentieMetIndexOf = (tekst, zoekterm) => {
        let count = 0;
        let positie = tekst.indexOf(zoekterm);

        while (positie !== -1) {
            count++;
            positie = tekst.indexOf(zoekterm, positie + 1);
        }

        return count;
    };

    document.getElementById("tellenKnop").addEventListener("click", function () {
        let tekst = "Hierboven een kip met een ei";
        let zoekterm = `${letter.value}`;

        let indexOfTelling = telSequentieMetIndexOf(tekst, zoekterm);

        document.getElementById("note").innerText = `Letter "${letter.value}" komt ${indexOfTelling} keer voor (via indexOf).`;
    });
}
window.addEventListener("load", setup);